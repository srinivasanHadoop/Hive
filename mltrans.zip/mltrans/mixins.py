'''
Created on 14-May-2020

@author: srinivasan
'''


class CommonPipelineMixins:
    
    pass
