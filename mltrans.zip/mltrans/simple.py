'''
Created on 14-May-2020

@author: srinivasan
'''
import logging
from pyspark.ml.classification import LogisticRegression
from pyspark.ml.feature import IDF, Tokenizer, StringIndexer, CountVectorizer , \
    NGram, VectorAssembler
from pyspark.ml.pipeline import Pipeline, PipelineModel
from pyspark.sql.dataframe import DataFrame

from playground.play.mltrans.base import AbstractDataMLTransForm, \
    AbstractDataMLPredictTransForm
from playground.play.datatrans.mixins import TweetCorrectionMixin

_logger = logging.getLogger(__name__)


class SentimentModelPreparationTrans(AbstractDataMLTransForm):
    
    def getPrepareColExpr(self) -> list:
        return "_c0 as target,_c1 as id,_c2 as date,_c3 as flag,_c4 as user,_c5 as text".split(",")
    
    def preDataValidate(self, df:DataFrame) -> (bool, Exception):
        if len(df.head(1)) == 0:
            return (False, Exception("Data Frame is Empty"))
        return (True, None)
    
    def prepareModelData(self, df:DataFrame) -> (DataFrame, DataFrame):
        train_df, test_df = df.randomSplit([0.8, 0.2])
        _logger.info(f"Train data count : {train_df.count()}")
        _logger.info(f"Test data count : {test_df.count()}")
        return (train_df, test_df)
    
    def trainData(self, pipeline:Pipeline, train_data:DataFrame) -> PipelineModel:
        return  pipeline.fit(train_data)
    
    def saveModel(self, model, model_path):
        model.write().overwrite().save(model_path)
    
    def evaluate(self, model, test_data) -> DataFrame:
        predictions = model.transform(test_data)
        accuracy = predictions.filter(predictions.label == predictions.prediction).count() / float(predictions.count())
        _logger.info("Accuracy : {}".format(accuracy))
        return None
    
    def getPipelines(self) -> Pipeline:
        n = 3
        stages = []
        stages.append(Tokenizer(inputCol='text',
                                outputCol="words"))
        stages.extend(NGram(n=i, inputCol="words",
                  outputCol="{0}_grams".format(i)) 
                            for i in range(1, n + 1))
        stages.extend([CountVectorizer(vocabSize=5460,
                                       inputCol="{0}_grams".format(i),
                            outputCol="{0}_tf".format(i)) 
                                       for i in range(1, n + 1)])
        stages.extend([IDF(inputCol="{0}_tf".format(i),
                   outputCol="{0}_tfidf".format(i), minDocFreq=5) 
                   for i in range(1, n + 1)])
        stages.extend([VectorAssembler(inputCols=["{0}_tfidf".format(i) 
                                                   for i in range(1, n + 1)],
                                                   outputCol="features")])
        #stages.append(StringIndexer(inputCol='target', outputCol="label"))
        #stages.append(LogisticRegression(maxIter=100))
        return Pipeline().setStages(stages)


class SentimentModelPrediction(AbstractDataMLPredictTransForm, TweetCorrectionMixin):
    
    def loadAndGetModel(self, model_path):
        return PipelineModel.load(model_path)
    
    def predict_DataSet(self, model, df:DataFrame) -> DataFrame:
        pdf = self.getHashtagDataFrame(df)
        return model.transform(pdf).select(["text", "prediction"])
