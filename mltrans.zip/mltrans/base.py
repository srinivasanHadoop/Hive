'''
Created on 28-Apr-2020

@author: srinivasan
'''

from abc import abstractmethod
from pyspark.ml.pipeline import Pipeline, PipelineModel
from pyspark.sql.dataframe import DataFrame
from pyspark.storagelevel import StorageLevel

from playground.play.core.base import AbstractDataSetTransOpe
from playground.play.mltrans.mixins import CommonPipelineMixins
from playground.play.spark.dataframe_ope import CommonOperation
from playground.play.spark.manager import SparkSessionManager


class AbstractDataMLTransForm(AbstractDataSetTransOpe, CommonPipelineMixins):
    
    def __init__(self, spark:SparkSessionManager):
        super().__init__(spark)
        self.__commonOpe = CommonOperation
    
    @property
    def common(self):
        return self.__commonOpe
    
    def transform(self, df:DataFrame, readers, writer) -> DataFrame:
        self._readers = readers
        self._writers = writer
        pre_cols = self.getPrepareColExpr()
        if pre_cols and len(pre_cols) > 0 :
            df = df.selectExpr(*pre_cols)
        df.persist(StorageLevel.MEMORY_AND_DISK)
        isValid, error = self.preDataValidate(df)
        if not isValid:
            raise error
        train_data, test_data = self.prepareModelData(df)
        model = self.trainData(self.getPipelines(), train_data)
        self.saveModel(model, self.modelPath)
        final_df = self.evaluate(model, test_data)
        df.unpersist()
        return final_df
    
    @abstractmethod
    def getPrepareColExpr(self) -> list:
        raise NotImplementedError('Must provide implementation in subclass.')

    """
    Pre validate the data
    """

    @abstractmethod
    def preDataValidate(self, df:DataFrame) -> (bool, Exception):
        raise NotImplementedError('Must provide implementation in subclass.')
    
    """
    Prepare data for Model
    """

    @abstractmethod
    def prepareModelData(self, df:DataFrame) -> (DataFrame, DataFrame):
        raise NotImplementedError('Must provide implementation in subclass.')
    
    """"
    """

    @abstractmethod
    def saveModel(self, model, model_path):
        raise NotImplementedError('Must provide implementation in subclass.')
    
    """
    trainData mode using Dataset
    """

    @abstractmethod
    def trainData(self, pipeline:Pipeline, train_data:DataFrame) -> PipelineModel:
        raise NotImplementedError('Must provide implementation in subclass.')

    """
    Evaluate the Model
    """

    @abstractmethod
    def evaluate(self, model, test_data:DataFrame) -> DataFrame:
        raise NotImplementedError('Must provide implementation in subclass.')
    
    """
    Get the current model Pipelines
    """

    @abstractmethod
    def getPipelines(self) -> Pipeline:
        raise NotImplementedError('Must provide implementation in subclass.')


class AbstractDataMLPredictTransForm(AbstractDataSetTransOpe, CommonPipelineMixins):
    
    """
    TransForm & apply model prediction on the Dataset
    """

    def transform(self, df:DataFrame, readers, writer) -> DataFrame:
        self._readers = readers
        self._writers = writer
        model = self.loadAndGetModel(self.modelPath)
        return self.predict_DataSet(model, df)
    
    """
    Load and get the model from model path
    """

    @abstractmethod
    def loadAndGetModel(self, model_path):
        raise NotImplementedError('Must provide implementation in subclass.')

    """
    Predict the dataset
    """

    @abstractmethod
    def predict_DataSet(self, model, df:DataFrame) -> DataFrame:
        raise NotImplementedError('Must provide implementation in subclass.')
        
