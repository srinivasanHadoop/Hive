=====
Usage
=====

To use dbjobadequacy in a project::

    import dbjobadequacy
