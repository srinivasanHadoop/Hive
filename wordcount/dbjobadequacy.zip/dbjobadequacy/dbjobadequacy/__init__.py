"""Top-level package for dbjobadequacy."""

__author__ = """Srinivasan Ramalingam"""
__email__ = 'sradmin7@hyperiongrp.com'
__version__ = '0.1.0'