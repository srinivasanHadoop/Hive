from delta import DeltaTable
from pyspark.sql import DataFrame

from dbjobadequacy.transform.spark.base import AbstractDataTransForm
from dbjobadequacy.utils.spark import DatabricksUtils


class Scd1DataTransForm(AbstractDataTransForm):

    def pre_data_validate(self, df: DataFrame) -> (bool, Exception):
        return (True, None)

    def data_transform(self, df: DataFrame) -> DataFrame:
        # check delta_table exist if not write data into delta path
        if not DatabricksUtils.check_file_exist(self.spark,
                                                self.config.get('delta_path')):
            self.write_data(df, 'delta', 0)
            return df
        else:
            delta_table = DeltaTable.forName(self.spark, self.config.get('delta_path'))
            delta_table.alias("hist").merge(df.alias("current"),
                                            self.config.get('join_contition')) \
                .whenMatchedUpdateAll() \
                .whenNotMatchedInsertAll() \
                .execute()
            return delta_table.toDF()

    def post_data_validate(self, df: DataFrame) -> (bool, Exception):
        return (True, None)


class Scd2DataTransForm(AbstractDataTransForm):
    pass


class Scd3DataTransForm(AbstractDataTransForm):
    pass
