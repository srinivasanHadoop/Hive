import logging
from abc import ABC, abstractmethod

from pyspark.sql import SparkSession, DataFrame

from dbjobadequacy.component.errors import SourceParamNullPointerException, MissingDataReaderException, \
    TargetParamNullPointerException, MissingDataWriterException
from dbjobadequacy.component.spark.errors import StreamNotSupportIntermediateWriteException


class _AbstractDataSetTransOpe(ABC):

    def __init__(self, spark: SparkSession,
                 readers, writers, reader_factory, writer_factory,
                 model_path, config):
        self.spark = spark
        self._readers = readers
        self._writers = writers
        self.__model_path = model_path
        self.__reader_factory = reader_factory
        self.__writer_factory = writer_factory
        self.__config = config

    @property
    def model_path(self):
        if not self.__model_path:
            self.__model_path = self.spark.conf \
                .get("application.model.path", '/tmp')
        return self.__model_path

    @property
    def config(self):
        return self.__config

    """
    Abstract data transform
    """

    @abstractmethod
    def transform(self, df: DataFrame) -> DataFrame:
        raise NotImplementedError('Must provide implementation in subclass.')

    """
    Get Intermediate Data Reader
    """

    def read_data(self, source_name: str, position: int):
        if not self._readers:
            raise SourceParamNullPointerException("DataReader has null value")
        sources = [s for s in self._readers if s.get('type').lower() == source_name.lower()]
        if sources:
            logging.info(f"reading data from {source_name}")
            return self.__reader_factory.reader_factory(source_name,
                                                        source_name.upper(),
                                                        sources[0]['configs'][position],
                                                        self.spark).read_data()
        raise MissingDataReaderException(f"{source_name} DataReader Source name is wrong")

    """
    Get Intermediate Data Writer
    """

    def write_data(self, df: DataFrame, source_name, position: int):
        if self.spark.conf \
                .get("application.disable.intermediate.writer", 'False') == 'True':
            raise StreamNotSupportIntermediateWriteException('Stream not Support Intermediate write')
        if not self._writers:
            raise TargetParamNullPointerException("Data Writer has null value")
        targets = [s for s in self._writers if s.get('type').lower() == source_name.lower()]
        if targets:
            return self.__writer_factory.writer_factory(source_name,
                                                        source_name.upper(),
                                                        targets[0]['configs'][position],
                                                        self.spark).write_data(df)
        raise MissingDataWriterException(f"{source_name} DataWriter Source name is wrong")


class AbstractDataTransForm(_AbstractDataSetTransOpe):

    def __init__(self, spark: SparkSession,
                 readers, writers, reader_factory, writer_factory,
                 model_path):
        super().__init__(spark, readers, writers, reader_factory, writer_factory,
                         model_path)
        # self.__commonOpe = CommonOperation

    @property
    def common(self):
        return self.__commonOpe

    def transform(self, df: DataFrame) -> DataFrame:
        is_valid, error = self.pre_data_validate(df)
        if not is_valid:
            raise error
        _df = self.data_transform(df)
        if _df:
            is_valid, error = self.post_data_validate(_df)
            if not is_valid:
                raise error
        return _df

    @abstractmethod
    def data_transform(self, df: DataFrame) -> DataFrame:
        raise NotImplementedError('Must provide implementation in subclass.')

    @abstractmethod
    def pre_data_validate(self, df: DataFrame) -> (bool, Exception):
        raise NotImplementedError('Must provide implementation in subclass.')

    @abstractmethod
    def post_data_validate(self, df: DataFrame) -> (bool, Exception):
        raise NotImplementedError('Must provide implementation in subclass.')


class AbstractStreamDataTransForm(AbstractDataTransForm):

    def pre_data_validate(self, df: DataFrame) -> (bool, Exception):
        return (True, None)

    def post_data_validate(self, df: DataFrame) -> (bool, Exception):
        return (True, None)
