'''

@author: srinivasan
'''
from pyspark.sql.dataframe import DataFrame
from pyspark.sql.functions import lit

from dbjobadequacy.transform.spark.base import AbstractDataTransForm


class DefaultDataTransformOpe(AbstractDataTransForm):

    def pre_data_validate(self, df: DataFrame) -> (bool, Exception):
        return (True, None)

    def data_transform(self, df: DataFrame) -> DataFrame:
        # self.read_data('file', 0).show()
        # self.write_data(df.select('username'), 'file', 0)
        return df

    def post_data_validate(self, df: DataFrame) -> (bool, Exception):
        return (True, None)
