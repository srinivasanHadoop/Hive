import logging.config
from dependency_injector import providers, containers
from pyspark.sql import SparkSession

from dbjobadequacy.services.container import SparkJobServiceContainer


class CommonContainer(containers.DeclarativeContainer):
    config = providers.Configuration(strict=True)
    logging = providers.Resource(
        logging.config.fileConfig,
        fname="logging.ini",
    )


class JobApplication(containers.DeclarativeContainer):
    config = providers.Configuration(strict=True)
    spark = providers.Dependency(instance_of=SparkSession)
    config_container = providers.Container(
        CommonContainer, config=config,
    )
    service_selector = providers.Selector(
        config.spark_or_pandas_or_python,
        spark=providers.Container(SparkJobServiceContainer,
                                  config=config,
                                  spark=spark),
        pandas=providers.Container(SparkJobServiceContainer,
                                   config=config,
                                   spark=spark),
        python=providers.Container(SparkJobServiceContainer,
                                   config=config,
                                   spark=spark),
    )
