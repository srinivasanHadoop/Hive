'''
@author: srinivasan
'''


class MissingPublisherException(Exception):
    pass


class MissingDataReaderException(Exception):
    pass


class MissingDataWriterException(Exception):
    pass


class MissingConsumerException(Exception):
    pass


class InValidJobTypeException(Exception):
    pass


class SourceParamNullPointerException(Exception):
    pass


class TargetParamNullPointerException(Exception):
    pass


class TransClassNameNullPointerException(Exception):
    pass
