import pyspark.sql.functions as F
from pyspark.sql.functions import when, lit, col, trim


class ColumnOperation:

    @staticmethod
    def remove_all_whitespace(col):
        return F.regexp_replace(col, "\\s+", "")

    @staticmethod
    def remove_non_word_characters(col):
        return F.regexp_replace(col, "[^\\w\\s]+", "")

    @staticmethod
    def anti_trim(col):
        return F.regexp_replace(col, "\\b\\s+\\b", "")

    @staticmethod
    def isNullOrBlank(self):
        return (self.isNull()) | (trim(self) == "")

    @staticmethod
    def isNotIn(self, list):
        return ~(self.isin(list))

    @staticmethod
    def nullBetween(self, lower, upper):
        return when(lower.isNull() & upper.isNull(), False).otherwise(
            when(self.isNull(), False).otherwise(
                when(lower.isNull() & upper.isNotNull() & (self <= upper), True).otherwise(
                    when(
                        lower.isNotNull() & upper.isNull() & (self >= lower), True
                    ).otherwise(self.between(lower, upper))
                )
            )
        )
