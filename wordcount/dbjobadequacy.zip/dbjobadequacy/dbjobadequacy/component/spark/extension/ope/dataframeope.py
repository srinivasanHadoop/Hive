'''

@author: srinivasan
'''
import sys
import re
from collections import OrderedDict
from typing import Any, Dict, List
from pyspark import Row
from pyspark.sql import Window
from pyspark.sql.types import DataType
import pyspark.sql.functions as F
from pyspark.sql.dataframe import DataFrame

from dbjobadequacy.utils import verify_func_in


class RowOperation:

    def convert_to_row(d: Dict[Any, Any]) -> Row:
        return Row(**OrderedDict(sorted(d.items())))


class DataFrameOperation:

    @staticmethod
    def cast(df,
             col: str,
             to_type: str,
             new_col: str = None) -> DataFrame:
        casted_column = df[col].cast(to_type)
        return df.withColumn(new_col if new_col else col,
                             casted_column)

    @staticmethod
    def filter_by_list(
            df,
            col: str,
            choice_list: List[str]) -> DataFrame:
        return df.where((F.col(col).isin(choice_list)))

    @staticmethod
    def select_columns_regex(df, regex):
        return df.select([c for c in df.columns if re.search(regex, c)])

    @staticmethod
    def cast_int_to_date(df: DataFrame, col_nm: str,
                         date_format: str = 'yyyyMMdd') -> DataFrame:
        in_vals: List[type] = [DataFrame, str, str]
        exp_vals: List[type] = [type(df), type(col_nm), type(date_format)]
        verify_func_in(in_vals, exp_vals)
        return df.withColumn(col_nm,
                             F.to_date(F.col(col_nm)
                                       .cast('string'),
                                       date_format)
                             .alias(col_nm))

    @staticmethod
    def set_neg_to_zero(df: DataFrame, col_names: list) -> DataFrame:
        for col_name in col_names:
            df = df.withColumn(col_name,
                               F.when(df[col_name] < 0, F.lit(0)) \
                               .otherwise(df[col_name]))
        return df

    @staticmethod
    def set_miss_to_zero(df: DataFrame, col_names: list) -> DataFrame:
        for col_name in col_names:
            df = df.withColumn(col_name,
                               F.when(df[col_name].isNull(), F.lit(0)) \
                               .otherwise(df[col_name]))
        return df

    @staticmethod
    def remove_leading_zeros(df: DataFrame,
                             col_name: str) -> DataFrame:
        original_type: DataType = df.schema[col_name].dataType
        return df.withColumn(col_name,
                             F.regexp_replace(F.col(col_name),
                                              r'^[0]*', "")
                             .cast(original_type))

    @staticmethod
    def keep_alphanumeric_string(df: DataFrame, col_name: str) -> DataFrame:
        original_type: DataType = df.schema[col_name].dataType
        return df.withColumn(col_name, F.regexp_replace(F.col(col_name),
                                                        r'[^A-Za-z0-9 ]', "")
                             .cast(original_type))

    """
    Fill null's with last *non null* value in the window
    """

    @staticmethod
    def fill_backward(df: DataFrame, id_column: str, key_column: str, fill_column: str):
        return df.withColumn(
            'fill_bwd',
            F.first(fill_column, True).over(
                Window.partitionBy(id_column)
                    .orderBy(key_column)
                    .rowsBetween(0, sys.maxsize))
        ).drop(fill_column) \
            .withColumnRenamed('fill_bwd', fill_column)

    # Fill null's with last *non null* value in the window
    @staticmethod
    def fill_forward(df: DataFrame, id_column: str, key_column: str, fill_column: str):
        return df.withColumn(
            'fill_fwd',
            F.last(fill_column, True)
                .over(
                Window.partitionBy(id_column)
                    .orderBy(key_column)
                    .rowsBetween(-sys.maxsize, 0))
        ).drop(fill_column).withColumnRenamed('fill_fwd', fill_column)

    """infer schema to fix parquet to Spark's parquet"""

    @staticmethod
    def adjust_decimal_schema(df):
        for typ in df.schema:
            if typ.dataType.typeName() == 'decimal' \
                    and typ.dataType.precision < 19:
                typ.dataType.precision = 38
        return df


class ColumnNameOperation:

    @staticmethod
    def sort_columns(df: DataFrame, sort_order: str = "asc") -> DataFrame:
        sorted_col_names = sorted(df.columns)
        if sort_order == "desc":
            sorted_col_names = sorted(df.columns, reverse=True)
        return df.select(*sorted_col_names)

    @staticmethod
    def remove_white_space_col_names(df: DataFrame) -> DataFrame:
        from functools import reduce
        to_snake_case = lambda s: s.lower().replace(" ", "_")
        return reduce(lambda memo_df,
                             col_name: memo_df.withColumnRenamed(col_name, to_snake_case(col_name)),
                      df.columns, df)
