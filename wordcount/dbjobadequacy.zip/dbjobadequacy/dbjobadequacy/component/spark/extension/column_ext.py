from pyspark.sql.column import Column

from dbjobadequacy.component.spark.extension.ope.columnope import ColumnOperation

Column.isNullOrBlank = ColumnOperation.isNullOrBlank
Column.isNotIn = ColumnOperation.isNotIn
Column.nullBetween = ColumnOperation.nullBetween
Column.remove_all_whitespace = ColumnOperation.remove_all_whitespace
Column.remove_non_word_characters = ColumnOperation.remove_non_word_characters
Column.anti_trim = ColumnOperation.anti_trim
