'''
@author: srinivasan
'''


class SparkSessionNotInitializedException(Exception):
    pass


class HdfsNotSupportFileFormatException(Exception):
    pass


class StreamNotSupportIntermediateWriteException(Exception):
    pass
