'''
@author: srinivasan
'''
from abc import abstractmethod
from pyspark.sql.dataframe import DataFrame
from pyspark.sql.session import SparkSession

from dbjobadequacy.component.base import AbstractComponent
from dbjobadequacy.component.spark.mixins import SourceSinkMixins


class AbstractSource(SourceSinkMixins, AbstractComponent):

    def __init__(self, name: str,
                 conf: dict, spark: SparkSession):
        super().__init__(name, conf)
        self._spark: SparkSession = spark

    @abstractmethod
    def get_data_frame(self) -> DataFrame:
        raise NotImplementedError('Must provide implementation in subclass.')
