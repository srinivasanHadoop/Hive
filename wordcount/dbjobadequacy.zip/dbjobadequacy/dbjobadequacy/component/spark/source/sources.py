'''
@author: srinivasan
'''
from pydantic.main import BaseModel
from pyspark.sql.dataframe import DataFrame

from dbjobadequacy.component.spark.mixins import CommonStreamSourceReaderMixin
from dbjobadequacy.component.spark.source.base import AbstractSource
from dbjobadequacy.component.spark.source.basemodel import KafkaBaseModel, SocketBaseModel, RateBaseModel


class KafkaSource(AbstractSource, CommonStreamSourceReaderMixin):

    @staticmethod
    def extra_default_conf() -> dict:
        return {
            'other_conf': {
                'startingOffsets': 'latest',
                'failOnDataLoss': 'false'
            }
        }

    @staticmethod
    def validate_getconf(_conf) -> BaseModel:
        return KafkaBaseModel(**_conf)

    def get_data_frame(self) -> DataFrame:
        return self.data_read('kafka')

    def get_options(self) -> dict:
        opt = super().get_options()
        opt['kafka.bootstrap.servers'] = opt.get('kafka_bootstrap_servers')
        return opt


class SocketSource(AbstractSource, CommonStreamSourceReaderMixin):

    @staticmethod
    def extra_default_conf() -> dict:
        return {
            'host': 'localhost',
            'port': 9999,
        }

    @staticmethod
    def validate_getconf(_conf) -> BaseModel:
        return SocketBaseModel(**_conf)

    def get_data_frame(self) -> DataFrame:
        return self.data_read('socket')


class RateSource(AbstractSource, CommonStreamSourceReaderMixin):
    @staticmethod
    def extra_default_conf() -> dict:
        return {
            'rowsPerSecond': '10'
        }

    @staticmethod
    def validate_getconf(_conf) -> BaseModel:
        return RateBaseModel(**_conf)

    def get_data_frame(self) -> DataFrame:
        return self.data_read('rate')


class FileSource(AbstractSource, CommonStreamSourceReaderMixin):

    @staticmethod
    def extra_default_conf() -> dict:
        return {
            'host': 'localhost',
            'port': 9999,
        }

    @staticmethod
    def validate_getconf(_conf) -> BaseModel:
        return SocketBaseModel(**_conf)

    def get_data_frame(self) -> DataFrame:
        return self.data_read('socket')


class EventHubSource:
    pass


class ElasticSource:
    pass


class SalesforceSource:
    pass
