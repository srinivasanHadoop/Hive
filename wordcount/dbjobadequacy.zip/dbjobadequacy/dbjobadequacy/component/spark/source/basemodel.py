'''
@author: srinivasan
'''
from pydantic.main import BaseModel
from enum import Enum


class KafkaBaseModel(BaseModel):
    kafka_bootstrap_servers: str
    subscribe: str
    other_conf: dict


class SocketBaseModel(BaseModel):
    host: str
    port: int
    other_conf: dict


class RateBaseModel(BaseModel):
    rowsPerSecond: int
    other_conf: dict = {}


class FileEnum(str, Enum):
    csv = 'csv'
    json = 'json'
    parquet = 'parquet'
    orc = 'orc'
    delta = 'delta'


class FileBaseModel(BaseModel):
    format: FileEnum
    path: str
    other_conf: dict = {}


class EventHubBaseModel(BaseModel):
    event_hubs_connection_string: str
    other_conf: dict = {}
