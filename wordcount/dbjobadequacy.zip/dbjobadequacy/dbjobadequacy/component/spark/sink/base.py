'''
@author: srinivasan
'''
from abc import abstractmethod
from pydantic.main import BaseModel
from pyspark.sql.dataframe import DataFrame
from pyspark.sql.session import SparkSession

from dbjobadequacy.component.base import AbstractComponent
from dbjobadequacy.component.spark.mixins import SourceSinkMixins
from dbjobadequacy.component.spark.sink.basemodel import CommonStreamWriteModel

default_sink_conf = {
    'mode': 'append',
    'processingTime': '10 seconds',
    'other_conf': {}
}


class AbstractSink(SourceSinkMixins, AbstractComponent):

    def __init__(self, name: str, conf: dict, spark: SparkSession):
        super().__init__(name, conf)
        self._spark: SparkSession = spark

    @staticmethod
    def extra_default_conf() -> dict:
        return default_sink_conf

    def write_data(self, df: DataFrame):
        return self.write_data_stream(df)

    @abstractmethod
    def write_data_stream(self, df: DataFrame):
        raise NotImplementedError('Must provide implementation in subclass.')

    @staticmethod
    def validate_getconf(_conf) -> BaseModel:
        return CommonStreamWriteModel(**_conf)
