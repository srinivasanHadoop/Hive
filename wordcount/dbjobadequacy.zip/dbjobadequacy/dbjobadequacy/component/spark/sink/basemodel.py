'''
Created on 27-Apr-2020

@author: srinivasan
'''
from pydantic.main import BaseModel


class CommonStreamWriteModel(BaseModel):
    sinkmode: str = 'append'
    processingTime: str = '10 seconds'
    trigger_mode: str = "processingTime"
    queryName: str = "tableName"
    other_conf: dict = {}
