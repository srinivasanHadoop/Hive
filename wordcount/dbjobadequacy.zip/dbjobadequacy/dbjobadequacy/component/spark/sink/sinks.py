'''
@author: srinivasan
'''

from pyspark.sql.dataframe import DataFrame

from dbjobadequacy.component.spark.mixins import CommonDiskStreamWriter
from dbjobadequacy.component.spark.sink.base import AbstractSink


class ConsoleSink(AbstractSink, CommonDiskStreamWriter):

    def write_data_stream(self, df: DataFrame):
        return self._write_data_frame('console', df)


class ParquetSink(AbstractSink, CommonDiskStreamWriter):

    def write_data_stream(self, df: DataFrame):
        return self._write_data_frame('parquet', df)


class DeltaSink(AbstractSink, CommonDiskStreamWriter):

    def write_data_stream(self, df: DataFrame):
        return self._write_data_frame('delta', df)


class KafkaSink(AbstractSink, CommonDiskStreamWriter):

    def write_data_stream(self, df: DataFrame):
        return self._write_data_frame('kafka', df)


class MemorySink(AbstractSink, CommonDiskStreamWriter):

    def write_data_stream(self, df: DataFrame):
        return self._write_data_frame('memory', df)


class MongoDBSink(AbstractSink):

    def write_data_stream(self, df: DataFrame):
        pass


class ElasticSink(AbstractSink):

    def write_data_stream(self, df: DataFrame):
        pass
