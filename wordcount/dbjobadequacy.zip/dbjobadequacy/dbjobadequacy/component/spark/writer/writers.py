'''
@author: srinivasan
'''
import logging
from pydantic.main import BaseModel
from pyspark.sql.dataframe import DataFrame

from dbjobadequacy.component.spark.writer.base import AbstractDataWriter
from dbjobadequacy.component.spark.writer.basemodel import ConsoleModel, HiveModel, HDFSModel, JdbcModel

_logger = logging.getLogger(__name__)


class ConsoleWriter(AbstractDataWriter):

    @staticmethod
    def extra_default_conf() -> dict:
        return {}

    @staticmethod
    def validate_getconf(_conf) -> BaseModel:
        return ConsoleModel(**_conf)

    def write_data(self, df: DataFrame):
        _logger.info(f"started to write data into console")
        df.show(self.base_model.n, self.base_model.truncate,
                self.base_model.vertical)


class HiveDataWrite(AbstractDataWriter):

    @staticmethod
    def extra_default_conf() -> dict:
        return {}

    @staticmethod
    def validate_getconf(_conf) -> BaseModel:
        return HiveModel(**_conf)

    def write_data(self, df: DataFrame):
        _logger.info(f"started to write data into Hive table {self.base_model.database}.{self.base_model.tablename}")
        df.write.options(**self.base_model.other_conf). \
            insertInto(f"{self.base_model.database}.{self.base_model.tablename}",
                       self.base_model.overwrite == 'overwrite')


class FileDataWrite(AbstractDataWriter):

    @staticmethod
    def extra_default_conf() -> dict:
        return {}

    @staticmethod
    def validate_getconf(_conf) -> BaseModel:
        return HDFSModel(**_conf)

    def write_data(self, df: DataFrame):
        _logger.info("started to write data into HDFS")
        _jwrite = df.write
        if self.base_model.partitionBy:
            _jwrite = _jwrite.partitionBy(*self.base_model.partitionBy)
        if self.base_model.bucketBy:
            n = self.base_model.bucketBy['numBuckets']
            cols = self.base_model.bucketBy['cols']
            col1 = cols.pop(0)
            _jwrite = _jwrite.bucketBy(n, col1, *cols)
        if self.base_model.sortBy:
            cols = self.base_model.sortBy
            col1 = cols.pop(0)
            _jwrite = _jwrite.sortBy(col1, *cols)
        _jwrite.mode(self.base_model.mode).format(self.base_model.write_format) \
            .options(**self.base_model.other_conf) \
            .save(self.base_model.path)


class RDBMSDataWrite(AbstractDataWriter):

    @staticmethod
    def extra_default_conf() -> dict:
        return {}

    @staticmethod
    def validate_getconf(_conf) -> BaseModel:
        return JdbcModel(**_conf)

    def write_data(self, df: DataFrame):
        _logger.info("started to write data into RBMS")
        df.write.format("jdbc").mode(self.base_model.mode) \
            .options(**self.get_options()).save()


class MongoDBDataWrite:
    pass


class RedshiftDataWrite:
    pass


class ElasticSearchDataWrite:
    pass
