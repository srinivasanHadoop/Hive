'''
Created on 28-Apr-2020

@author: srinivasan
'''
from pydantic.main import BaseModel

from enum import Enum

from dbjobadequacy.component.spark.reader.basemodel import FileFormat


class OperationMode(str, Enum):
    append = 'append'
    overwrite = 'overwrite'
    ignore = 'ignore'
    errorifexists = 'errorifexists'


class SinkOutputMode(str, Enum):
    append = 'append'
    complete = 'complete'
    update = 'update'


class ConsoleModel(BaseModel):
    n: int = 20
    truncate: bool = True
    vertical: bool = False


class HiveModel(BaseModel):
    tablename: str
    database: str
    processingTime: str = '0 seconds'
    mode: OperationMode = OperationMode.append
    sinkmode = SinkOutputMode.append
    other_conf: dict = {}


class HDFSModel(BaseModel):
    write_format: FileFormat = FileFormat.csv
    path: str
    processingTime: str = '0 seconds'
    mode: OperationMode = OperationMode.append
    sinkmode = SinkOutputMode.append
    sortBy: list = None
    partitionBy: list = None
    bucketBy: dict = None
    other_conf: dict = {}


class JdbcModel(BaseModel):
    url: str
    user: str
    processingTime: str = '0 seconds'
    mode: OperationMode = OperationMode.append
    sinkmode = SinkOutputMode.append
    password: str
    driver: str
    dbtable: str
    other_conf: dict = {}
