'''
Created on 28-Apr-2020

@author: srinivasan
'''
from abc import abstractmethod
from pyspark.sql.dataframe import DataFrame
from pyspark.sql.session import SparkSession

from dbjobadequacy.component.base import AbstractComponent
from dbjobadequacy.component.spark.mixins import SourceSinkMixins


class AbstractDataSource(SourceSinkMixins, AbstractComponent):

    def __init__(self, name: str, conf: dict, spark: SparkSession):
        super().__init__(name, conf)
        self._spark: SparkSession = spark

    @abstractmethod
    def read_data(self) -> DataFrame:
        raise NotImplementedError('Must provide implementation in subclass.')
