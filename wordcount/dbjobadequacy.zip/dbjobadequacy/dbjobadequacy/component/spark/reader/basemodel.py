'''
@author: srinivasan
'''
from enum import Enum
from pydantic.main import BaseModel


class FileFormat(str, Enum):
    csv = 'csv'
    json = 'json'
    xml = 'xml'
    parquet = 'parquet'
    orc = 'orc'
    avro = 'avro'
    text = 'text'
    delta = 'delta'


class HiveModel(BaseModel):
    query: str
    other_conf: dict = {}


class HDFSModel(BaseModel):
    read_format: FileFormat = FileFormat.csv
    path: str
    data_schema_json: dict = None
    s3Key: str = None
    s3Secret: str = None
    other_conf: dict = {}


class JdbcModel(BaseModel):
    url: str
    user: str
    password: str
    driver: str
    dbtable: str
    partitionColumn: str = None
    numPartitions: str = "50"
    lowerBound: str = None
    upperBound: str = None
    other_conf: dict = {}
