'''
@author: srinivasan
'''
from pydantic.main import BaseModel
from pyspark.sql.dataframe import DataFrame

from dbjobadequacy.component.spark.errors import HdfsNotSupportFileFormatException
from dbjobadequacy.component.spark.reader.base import AbstractDataSource
from dbjobadequacy.component.spark.reader.basemodel import HiveModel, HDFSModel, JdbcModel


class HiveDataReader(AbstractDataSource):

    @staticmethod
    def extra_default_conf() -> dict:
        return {}

    @staticmethod
    def validate_getconf(_conf) -> BaseModel:
        return HiveModel(**_conf)

    def read_data(self) -> DataFrame:
        return self._spark.sql(self.get_options().get('query'))


class FileDataReader(AbstractDataSource):

    @staticmethod
    def extra_default_conf() -> dict:
        return {}

    @staticmethod
    def validate_getconf(_conf) -> BaseModel:
        if _conf.get('read_format') not in ['json', 'csv',
                                            'parquet', 'orc',
                                            'avro', 'xml',
                                            'delta']:
            raise HdfsNotSupportFileFormatException(f"Not support file format {_conf.get('read_format')}")
        return HDFSModel(**_conf)

    """
    Read data from HDFS Directory
    """

    def read_data(self) -> DataFrame:
        if self.base_model.s3Key:
            hadoop_conf = self._spark.sparkContext.hadoopConfiguration()
            hadoop_conf.set("fs.s3.impl", "org.apache.hadoop.fs.s3native.NativeS3FileSystem")
            hadoop_conf.set("fs.s3.awsAccessKeyId", self.base_model.s3Key)
            hadoop_conf.set("fs.s3.awsSecretAccessKey", self.base_model.s3Secret)
        read = self._spark.read.format(self.base_model.read_format)
        if self.base_model.data_schema_json:
            from pyspark.sql.types import StructType
            schema = StructType.fromJson(self.base_model.data_schema_json)
            read = read.schema(schema)
        return read.options(**self.base_model.other_conf) \
            .load(self.base_model.path)


class RDBMSDataReader(AbstractDataSource):

    @staticmethod
    def extra_default_conf() -> dict:
        return {}

    @staticmethod
    def validate_getconf(_conf) -> BaseModel:
        return JdbcModel(**_conf)

    """
    Read data from RDBMS table
    """

    def read_data(self) -> DataFrame:
        return self._spark.read.format("jdbc") \
            .options(**self.get_options()).load()


class MongoDBDataReader:
    pass
