from dependency_injector import containers, providers

from dbjobadequacy.component.spark.reader.readers import HiveDataReader, FileDataReader, RDBMSDataReader
from dbjobadequacy.component.spark.sink.sinks import KafkaSink, ConsoleSink, ParquetSink
from dbjobadequacy.component.spark.source.sources import KafkaSource, SocketSource, FileSource, RateSource
from dbjobadequacy.component.spark.writer.writers import HiveDataWrite, RDBMSDataWrite, ConsoleWriter, FileDataWrite


class SparkSourceContainer(containers.DeclarativeContainer):
    source_factory = providers.FactoryAggregate(
        kafka=providers.Factory(KafkaSource),
        socket=providers.Factory(SocketSource),
        file=providers.Factory(FileSource),
        rate=providers.Factory(RateSource),
    )


class SparkSinkContainer(containers.DeclarativeContainer):
    sink_factory = providers.FactoryAggregate(
        kafka=providers.Factory(KafkaSink),
        console=providers.Factory(ConsoleSink),
        parquet=providers.Factory(ParquetSink), )


class SparkReaderContainer(containers.DeclarativeContainer):
    reader_factory = providers.FactoryAggregate(
        hive=providers.Factory(HiveDataReader),
        file=providers.Factory(FileDataReader),
        rdbms=providers.Factory(RDBMSDataReader),
    )


class SparkWriterContainer(containers.DeclarativeContainer):
    writer_factory = providers.FactoryAggregate(
        hive=providers.Factory(HiveDataWrite),
        file=providers.Factory(FileDataWrite),
        rdbms=providers.Factory(RDBMSDataWrite),
        console=providers.Factory(ConsoleWriter),
    )
