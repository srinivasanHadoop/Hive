'''
@author: srinivasan
'''

from pyspark.sql.dataframe import DataFrame

from dbjobadequacy.utils.commonutils import get_dictionary_merge


# Source & Sink Common Implementation

class SourceSinkMixins:
    """
    Get Source or Sink Options
    """

    def get_options(self) -> dict:
        return get_dictionary_merge(self.base_model.dict(),
                                    'other_conf')

    """
    ShutDown the service @ runtime
    """

    def shutdown(self):
        if not self._spark:
            self._spark.stop()


"""
Common Disk Stream Writer
"""


class CommonDiskStreamWriter:
    """
    common implementation to write data frame on disk in Streaming fashion
    """

    def _write_data_frame(self, type_name: str, df: DataFrame):
        trigger_dict = {
            self.base_model.trigger_mode: True
            if self.base_model.trigger_mode == 'once' else self.base_model.processingTime}
        return df.writeStream \
            .trigger(**trigger_dict) \
            .outputMode(self.base_model.sinkmode) \
            .queryName(self.base_model.queryName) \
            .options(**self.base_model.other_conf) \
            .format(type_name) \
            .start()


class CommonStreamSourceReaderMixin:

    def data_read(self, type_name: str):
        return self._spark \
            .readStream \
            .format(type_name) \
            .options(**self.get_options()) \
            .load()
