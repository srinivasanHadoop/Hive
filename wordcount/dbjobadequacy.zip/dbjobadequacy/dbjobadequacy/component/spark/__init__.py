from dependency_injector.providers import Configuration
from pyspark.sql import SparkSession
from dataclasses import dataclass
from dbjobadequacy.component.spark.errors import SparkSessionNotInitializedException


@dataclass
class SparkSessionManager:
    spark: SparkSession
    conf: Configuration

    def set_config_or_initialize_session(self):
        spark_conf = self.conf.get('spark_config', {})
        hadoop_conf = self.conf.get('hadoop_config', {})
        for k, v in spark_conf.items():
            self.spark.conf.set(k, v)
        for k, v in hadoop_conf.items():
            self.spark.sparkContext._jsc.hadoopConfiguration().set(k, v)

    @property
    def spark_context(self):
        if not self.spark:
            raise SparkSessionNotInitializedException("""Spark Session not initialized. 
        please call initialize_session method before calling this method""")
        return self.spark.sparkContext

    """
   Register Java Functions into pyspark
   """

    def register_java_functions(self, fcts: dict):
        for alias, name in fcts.items():
            self.spark.udf.registerJavaFunction(alias, name)

    """
    Clear Cache
    """

    def clear_cache(self):
        self.spark.catalog.clearCache()
