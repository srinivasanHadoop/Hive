from abc import ABC, abstractmethod
import logging
from pydantic.error_wrappers import ValidationError
from pydantic.main import BaseModel

logger = logging.getLogger(__name__)


class AbstractComponent(ABC):

    def __init__(self, name: str, conf: dict):
        self._name = name
        self._conf = conf if conf else {}
        extra_conf = self.extra_default_conf()
        if extra_conf:
            self._conf = {**extra_conf, **self._conf}
        try:
            self.__basemodel = self.validate_getconf(self._conf)
        except ValidationError as e:
            logger.error(e.json())
            raise Exception(e.json())

    @property
    def base_model(self):
        return self.__basemodel

    @staticmethod
    @abstractmethod
    def validate_getconf(_conf) -> BaseModel:
        raise NotImplementedError('Must provide implementation in subclass.')

    @staticmethod
    @abstractmethod
    def extra_default_conf() -> dict:
        raise NotImplementedError('Must provide implementation in subclass.')

    @abstractmethod
    def shutdown(self):
        raise NotImplementedError('Must provide implementation in subclass.')

    def __str__(self):
        return self._name
