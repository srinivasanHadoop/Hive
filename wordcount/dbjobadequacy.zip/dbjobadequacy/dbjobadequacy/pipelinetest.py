from pyspark.sql import SparkSession
from scopt import SparkConfOptimizer
from scopt.instances import Instance

executor_instance = Instance(8, 50)
num_nodes = 3
deploy_mode = 'client'

sco = SparkConfOptimizer(executor_instance, num_nodes, deploy_mode)
print(sco)
exit(0)

from dbjobadequacy.pipeline import JobPipline

spark = SparkSession.builder.appName('job_name') \
    .config('spark.jars.packages', 'io.delta:delta-core_2.12:1.0.0') \
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog").getOrCreate()

from pyspark.sql.dataframe import DataFrame
from pyspark.sql.functions import lit

from dbjobadequacy.transform.spark.base import AbstractDataTransForm


class SampleDefaultDataTransformOpe(AbstractDataTransForm):

    def pre_data_validate(self, df: DataFrame) -> (bool, Exception):
        return (True, None)

    def data_transform(self, df: DataFrame) -> DataFrame:
        return df.withColumn('hadoop', lit('Srini'))

    def post_data_validate(self, df: DataFrame) -> (bool, Exception):
        return (True, None)


JobPipline('plan_stream.json', spark,
           None).execute_pipeline_operation()
