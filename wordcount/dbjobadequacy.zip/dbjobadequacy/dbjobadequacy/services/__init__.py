from pyspark import AccumulatorParam


class RotateFileAccumulator(AccumulatorParam):

    def zero(self, init_value: str):
        return init_value

    def addInPlace(self, v1: str, v2: str):
        return v2
