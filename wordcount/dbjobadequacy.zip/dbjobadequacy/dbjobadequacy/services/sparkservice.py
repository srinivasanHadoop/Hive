import os.path
from abc import ABC, abstractmethod
from dataclasses import dataclass
import logging
import copy
from dependency_injector import containers
from dependency_injector.providers import Configuration
from pyspark.sql import DataFrame

from dbjobadequacy.component.errors import TransClassNameNullPointerException
from dbjobadequacy.component.spark import SparkSessionManager
from dbjobadequacy.services import RotateFileAccumulator
from dbjobadequacy.utils.commonutils import get_class

_logger = logging.getLogger(__name__)

pyspark_log = logging.getLogger('pyspark')
pyspark_log.setLevel(logging.ERROR)


@dataclass(frozen=True)
class AbstractSparkService(ABC):
    conf: Configuration
    _sparkSessionMgr: SparkSessionManager
    DEFAULT_TRANS_CLASS = 'dbjobadequacy.transform.spark.basic.DefaultDataTransformOpe'

    def start_service(self):
        self._sparkSessionMgr.spark.conf \
            .set("application.model.path", self.conf.get('model_path', '/tmp'))
        self.__register_udf()
        self._start()

    def __register_udf(self):
        pass

    @abstractmethod
    def _start(self):
        raise NotImplementedError('Must provide implementation in subclass.')

    """
    tail recursive
    """

    def perform_transform_tasks(self, tasks, df: DataFrame) -> DataFrame:
        while True:
            if not tasks:
                return df
            task = tasks.pop(0)
            _logger.info(f"performing transformation logic {task['step']}")
            df = task['class'](self._sparkSessionMgr.spark, task.get('readers', None),
                               task.get('writers', None), self.reader_package,
                               self.writer_package, self.conf.get('model_path', None),
                               task.get('config', {})) \
                .transform(df)

    """
    Convert the class name to class Object
    """

    def _get_transform_tasks(self, type_nm='transforms'):

        def __trans(trans):
            if not trans.get('classname'):
                raise TransClassNameNullPointerException("class name is null")
            trans['class'] = get_class(trans.get('classname'))
            return trans

        if not self.conf.get(type_nm, None):
            self.conf[type_nm] = [{"step": 1,
                                   "classname": self.DEFAULT_TRANS_CLASS}]
        lis = [__trans(t) for t in self.conf[type_nm]]
        return sorted(lis, key=lambda i: i['step'])


@dataclass(frozen=True)
class SparkBatchService(AbstractSparkService):
    reader_package: containers.DeclarativeContainer
    writer_package: containers.DeclarativeContainer

    def _start(self):
        _logger.info("started Spark batch application")
        sdf = self.reader_package.reader_factory(self.conf.get('source').get('type'),
                                                 self.conf.get('source').get('type').upper(),
                                                 self.conf.get('source').get('config'),
                                                 self._sparkSessionMgr.spark).read_data()

        tasks = self._get_transform_tasks()
        tdf = self.perform_transform_tasks(tasks.copy(), sdf)
        self.writer_package.writer_factory(self.conf.get('writer').get('type'),
                                           self.conf.get('writer').get('type').upper(),
                                           self.conf.get('writer').get('config', {}),
                                           self._sparkSessionMgr.spark).write_data(tdf)


@dataclass(frozen=True)
class SparkStreamingService(AbstractSparkService):
    source_package: containers.DeclarativeContainer
    sink_package: containers.DeclarativeContainer
    reader_package: containers.DeclarativeContainer
    writer_package: containers.DeclarativeContainer

    def _start(self):
        sdf = self.source_package.source_factory(self.conf.get('source').get('type'),
                                                 self.conf.get('source').get('type').upper(),
                                                 self.conf.get('source').get('config'),
                                                 self._sparkSessionMgr.spark).get_data_frame()
        tasks = self._get_transform_tasks()
        pre_trans_tasks = self._get_transform_tasks('pre_transform')
        if self.conf.get('raw_writer', {}).get('writers', []) or \
                self.conf.get('intermediate_action', False):
            from pyspark import StorageLevel
            path_suffix_acc = self._sparkSessionMgr.spark.sparkContext \
                .accumulator("", RotateFileAccumulator())
            writer = self.__get_data_writer(self.conf.get('writer'))

            def foreach_batch_function(df, epoch_id):
                _logger.info(f"started Batch job id is {epoch_id}")
                df.persist(StorageLevel.MEMORY_AND_DISK)
                if len(df.head(1)) > 0:
                    if self.conf.get('raw_writer', {}).get('writers', []):
                        _file_rotate_format = self.conf.get('raw_writer', {}).get('format')
                        for raw_write in self.conf.get('raw_writer', {}) \
                                .get('writers', []):
                            if _file_rotate_format and \
                                    raw_write.get('config', {}).get('path', None):
                                copied_raw_write = copy.deepcopy(raw_write)
                                copied_raw_write['config']['path'] = os.path.join(
                                    copied_raw_write.get('config', {}).get('path', None),
                                    self.__get_raw_suffix_path(path_suffix_acc,
                                                               _file_rotate_format))
                            self.__get_data_writer(copied_raw_write).write_data(df)
                    tdf = self.perform_transform_tasks(pre_trans_tasks.copy(), df)
                    tdf = self.perform_transform_tasks(tasks.copy(), tdf)
                    writer.write_data(tdf)
                else:
                    df.printSchema()
                df.unpersist()

            sink = sdf.writeStream.outputMode(self.conf.get('writer')
                                              .get('config', {}).get('sinkmode', 'append'))

            if self.conf.get('writer').get('config', {}).get('trigger_mode', None):
                trigger_mode = self.conf.get('writer').get('config', {}).get('trigger_mode', None)
                trigger_dict = {
                    trigger_mode: True
                    if trigger_mode == 'once'
                    else self.conf.get('writer').get('config', {}).get('processingTime', "10 seconds")}
                sink = sink.trigger(**trigger_dict)

            if self.conf.get('writer').get('config', {}).get('other_conf', None):
                sink = sink.options(**self.conf.get('writer').get('config', {}).get('other_conf', None))
            sink.foreachBatch(foreach_batch_function).start().awaitTermination()

        else:
            self._sparkSessionMgr.spark.conf \
                .set("application.disable.intermediate.writer", 'True')
            sdf = self.perform_transform_tasks(pre_trans_tasks.copy(), sdf)
            sdf = self.perform_transform_tasks(tasks.copy(), sdf)
            self.sink_package.sink_factory(self.conf.get('writer').get('type'),
                                           self.conf.get('writer').get('type').upper(),
                                           self.conf.get('writer').get('config', {}),
                                           self._sparkSessionMgr.spark) \
                .write_data(sdf).awaitTermination()

    def __get_raw_suffix_path(self, path_suffix_acc,
                              _file_rotate_format):
        from datetime import datetime
        new_folder_suffix = datetime.today() \
            .strftime(_file_rotate_format)
        if path_suffix_acc.value != new_folder_suffix:
            path_suffix_acc += new_folder_suffix
        return path_suffix_acc.value

    def __get_data_writer(self, config):
        return self.writer_package.writer_factory(
            config.get('type'),
            config.get('type').upper(),
            config.get('config', {}),
            self._sparkSessionMgr.spark)
