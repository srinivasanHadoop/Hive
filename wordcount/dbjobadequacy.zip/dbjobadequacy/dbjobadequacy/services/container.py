from dependency_injector import providers, containers
from pyspark.sql import SparkSession

from dbjobadequacy.component.spark import SparkSessionManager
from dbjobadequacy.component.spark.containers import SparkSourceContainer, SparkReaderContainer, SparkWriterContainer, \
    SparkSinkContainer
from dbjobadequacy.services.sparkservice import SparkStreamingService, SparkBatchService


class SparkStreamServiceContainer(containers.DeclarativeContainer):
    config = providers.Configuration(strict=True)
    spark_session_manager = providers.Dependency()
    source_package = providers.Container(
        SparkSourceContainer,
    )
    sink_package = providers.Container(
        SparkSinkContainer,
    )
    reader_package = providers.Container(
        SparkReaderContainer,
    )
    writer_package = providers.Container(
        SparkWriterContainer,
    )
    spark_service = providers.Singleton(SparkStreamingService,
                                        conf=config,
                                        _sparkSessionMgr=spark_session_manager,
                                        source_package=source_package,
                                        sink_package=sink_package,
                                        reader_package=reader_package,
                                        writer_package=writer_package)


class SparkBatchServiceContainer(containers.DeclarativeContainer):
    config = providers.Configuration(strict=True)
    spark_session_manager = providers.Dependency()
    reader_package = providers.Container(
        SparkReaderContainer,
    )
    writer_package = providers.Container(
        SparkWriterContainer,
    )
    spark_service = providers.Singleton(SparkBatchService,
                                        conf=config,
                                        _sparkSessionMgr=spark_session_manager,
                                        reader_package=reader_package,
                                        writer_package=writer_package)


class SparkJobServiceContainer(containers.DeclarativeContainer):
    config = providers.Configuration(strict=True)
    spark = providers.Dependency(instance_of=SparkSession)
    spark_session_manager = providers.Singleton(SparkSessionManager,
                                                spark=spark,
                                                conf=config)
    spark_service_selector = providers.Selector(
        config.batch_or_stream,
        batch=providers.Container(SparkBatchServiceContainer,
                                  config=config,
                                  spark_session_manager=spark_session_manager),
        stream=providers.Container(SparkStreamServiceContainer,
                                   config=config,
                                   spark_session_manager=spark_session_manager),
    )
