import logging
import json
import os
import re
from functools import wraps
from typing import List


def verify_func_in(in_vals: List[type],
                   exp_vals: List[type]):
    assert in_vals == exp_vals


def Singleton(cls):
    _singleton = {}

    @wraps(cls)
    def wrapSingleton(*args, **kwargs):
        if cls not in _singleton:
            _singleton[cls] = cls(*args, **kwargs)
        return cls(*args, **kwargs)

    return wrapSingleton


@Singleton
class KeyVaultUtils:

    def __init__(self, scope, dbutils):
        self.scope = scope
        self.dubutils = dbutils

    def get_value(self, key):
        logging.info(f"Getting ${key} value from keyvault.")
        return self.dbutils.secrets.get(scope=self.scope, key=key)


@Singleton
class ConfigUtils:

    def __init__(self, config_file_path, dbutils):
        self.config_file_path = config_file_path
        self.dbutils = dbutils
        self.keyvault = None

    def get_config(self):
        job_config = self.__read_json_file()
        self.__substitute_keyvault_vars(job_config)
        # self.__setup_keyvault(job_config.get('key_vault_scope'))
        return job_config

    @staticmethod
    def __cast_to_type(s):
        try:
            return int(s)
        except ValueError:
            try:
                return float(s)
            except ValueError:
                return s

    def __substitute_keyvault_vars(self, d):
        for key in d.keys():
            v = d.get(key)
            if isinstance(v, str):
                m = re.match('\${(\w+)\:-(\w+)}', v)
                if m:
                    env_name = m.group(1)
                    def_val = m.group(2)
                    env_val = os.environ.get(env_name)
                    if env_val is None:
                        env_val = self.__cast_to_type(def_val)
                    d[key] = env_val
            elif isinstance(v, dict):
                self.__substitute_keyvault_vars(v)
            elif isinstance(v, list):
                for d in v:
                    if isinstance(d, dict):
                        self.__substitute_keyvault_vars(d)

    def __setup_keyvault(self, scope):
        self.keyvault = KeyVaultUtils(scope,
                                      self.dbutils)

    def __read_json_file(self):
        logging.info(f"Reading Configuration file from {self.config_file_path} path")
        if os.path.isfile(self.config_file_path):
            with open(self.config_file_path, "r") as f:
                return json.load(f)
        else:
            raise Exception(f'Configuration File not found:{self.config_file_path}')
