from importlib import import_module
import json
from time import gmtime, strftime
import time
from datetime import datetime, date
from decimal import Decimal

"""
Get class from className String object
"""


def get_class(class_str: str):
    try:
        if len(class_str.split('.')) == 1:
            class_str = f'__main__.{class_str}'
        module_path, class_name = class_str.rsplit('.', 1)
        module = import_module(module_path)
        return getattr(module, class_name)
    except (ImportError, AttributeError):
        raise ImportError(class_str)


"""
Order dictionary based on the value
"""


def split_order_plug(ls: dict = dict()):
    return {k: v for k, v in
            sorted(ls.items(), key=lambda item: item[1])}


"""
Get timeSTamp
"""


def timestamp(date_time_object):
    return int(time.mktime(date_time_object.timetuple()))


"""
Get Current Date Time
"""


def get_current_date_time():
    return strftime("%Y-%m-%d_%H:%M:%S", gmtime())


"""
Combine the two dictionary
"""


def get_dictionary_merge(conf, remove_key, is_key=True):
    other_conf = conf.get(remove_key, {}) if is_key else remove_key
    if not other_conf:
        return conf
    return {**other_conf, **conf}


"""
Configuration validator
"""


def config_validator(data):
    try:
        json.loads(data)
        return True, "valid configuration"
    except ValueError as error:
        return False, f"invalid configuration: {error}"


"""Supports date and decimal objects"""


class JsonEncoder(json.JSONEncoder):

    def default(self, value):
        if isinstance(value, date):
            return value.strftime("%Y-%m-%d")
        if isinstance(value, Decimal):
            return float(value)
        return super(JsonEncoder, self).default(value)
