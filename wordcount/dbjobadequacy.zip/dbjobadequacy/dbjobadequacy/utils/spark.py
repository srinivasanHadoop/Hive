from pyspark.sql import SparkSession
import uuid as _uuid

"""
Get new dbutils
"""


def get_dbutils(spark: SparkSession):
    try:
        from pyspark.dbutils import DBUtils
        dbutils = DBUtils(spark)
    except ImportError:
        import IPython
        dbutils = IPython.get_ipython().user_ns["dbutils"]
    return dbutils


"""
get Unique name
"""


def get_unique_name(prefix) -> str:
    temp_view_name = f"{prefix}_{_uuid.uuid4().hex}"
    return temp_view_name


class DatabricksUtils:

    @staticmethod
    def check_file_exist(spark, path):
        try:
            get_dbutils(spark).fs.ls(path)
            return True
        except Exception as e:
            if 'java.io.FileNotFoundException' in str(e):
                return False
            else:
                raise
