import logging
import os
from abc import ABC, abstractmethod

from pyspark.sql import SparkSession


class AbstractStorageUtils(ABC):

    def __init__(self,
                 mount_point: str,
                 storage_config: dict,
                 secrets_config: dict,
                 is_oauth: bool,
                 spark: SparkSession,
                 dbutils):
        self.mount_point = os.path.join("/mnt", mount_point)
        self.storage_config = storage_config
        self.secrets_config = secrets_config
        self.dbutils = dbutils
        self.spark = spark
        self.is_oauth = is_oauth
        self.initialize()

    @abstractmethod
    def initialize(self):
        raise NotImplementedError("initialize method not yet implemented")

    @abstractmethod
    def mount(self, config: dict = {}):
        raise NotImplementedError("Mount method not yet implemented")

    def unmount(self):
        logging.info(f"{self.mount_point} Unmount file system.")
        if any(mount.mountPoint == self.mount_point
               for mount in self.list_mounts()):
            self.dbutils.fs.unmount(self.mount_point)
        else:
            logging.warning(f"no path {self.mount_point} mounted.")

    def list_mounts(self):
        logging.info("list the file system mounts")
        return self.dbutils.fs.mounts()


class AzureStorageUtils(AbstractStorageUtils):

    def initialize(self):
        if self.is_oauth:
            pass
        else:
            self.storage_name = self.storage_config['storageaccountname']
            self.container_name = self.storage_config['containername']
            self.secret_key = self.secrets_config['secret_key']

    def mount(self, config: dict = {}):
        if not any(mount.mountPoint == self.mount_point
                   for mount in self.list_mounts()):
            logging.info(f"Started to Mount the {self.mount_point} "
                         f"into Azure {'Blob storage' if config.get('isBlob') else 'ADLS Gen2 Storage'}")
            try:
                if self.is_oauth:
                    self.__oauth_mount(config.get('isBlob'))
                else:
                    self.__mount(config.get('isBlob'))

            except Exception as e:
                logging.error(str(e))
                raise e
        else:
            logging.warning(f"{self.mount_point} Path already Mounted. "
                            f"Please use different on else it will use existing Source.")

    def __oauth_mount(self, is_blob):
        pass

    def __mount(self, is_blob):
        self.dbutils.fs.mount(
            source=f"wasbs://{self.container_name}@{self.storage_name}.blob.core.windows.net"
            if is_blob else "",
            mount_point=self.mount_point,
            extra_configs={
                f"fs.azure.account.key.{self.storage_name}.blob.core.windows.net": self.secret_key
            } if is_blob else "")


class S3StorageUtils(AbstractStorageUtils):
    pass
