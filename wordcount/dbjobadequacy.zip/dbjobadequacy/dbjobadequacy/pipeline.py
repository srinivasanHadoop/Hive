import logging
from dataclasses import dataclass
from typing import Any

from dependency_injector.wiring import inject, Provide
from pyspark.sql import SparkSession

from dbjobadequacy.component.spark import SparkSessionManager
from dbjobadequacy.containers import JobApplication
from dbjobadequacy.services.container import SparkJobServiceContainer
from dbjobadequacy.utils import ConfigUtils


@dataclass
class JobPipline:
    config_path: str
    spark: SparkSession
    dbutils: Any
    config: dict = None

    def __post_init__(self):
        if not self.config:
            self.config = self.__get_config_dict(self.dbutils)

    def __get_config_dict(self, dbutils):
        return ConfigUtils(self.config_path, dbutils).get_config()

    def __init_get_app_container(self):
        job_container = JobApplication(spark=self.spark)
        job_container.init_resources()
        logging.info("initializing Application Container.")
        job_container.config.from_dict(
            self.config.get('app')
        )
        logging.info("initialized Application Container.")
        return job_container

    @inject
    def __spark_service(self, spark_session_manager: SparkSessionManager = Provide[
        SparkJobServiceContainer.spark_session_manager],
                        spark_service_selector=Provide[SparkJobServiceContainer.spark_service_selector]):
        spark_session_manager.set_config_or_initialize_session()
        spark_service_selector.spark_service().start_service()

    def __pandas_service(self):
        pass

    def __python_service(self):
        pass

    def __call_service(self, service_type):
        service_dict = {'spark': self.__spark_service,
                        'pandas': self.__pandas_service,
                        'python': self.__python_service}
        service_dict.get(service_type)()

    def execute_pipeline_operation(self):
        job_container = self.__init_get_app_container()
        job_container.config.set("spark_or_pandas_or_python",
                                 self.config.get('engine_type'))
        job_container.config.set("batch_or_stream",
                                 'stream' if self.config.get('app')
                                 .get('is_stream', False) else 'batch')
        job_service = job_container.service_selector()
        job_service.wire(modules=[__name__])
        self.__call_service(self.config.get('engine_type'))
