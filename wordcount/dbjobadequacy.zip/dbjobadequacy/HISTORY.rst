=======
History
=======

0.1.0 (2022-03-16)
------------------

* First release on PyPI.
