=============
dbjobadequacy
=============




.. image:: https://pyup.io/repos/github/sradmin7@hyperiongrp.com/dbjobadequacy/shield.svg
     :target: https://pyup.io/repos/github/sradmin7@hyperiongrp.com/dbjobadequacy/
     :alt: Updates



The DataBricks Job Utility streamlines the ETL process. 



Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
