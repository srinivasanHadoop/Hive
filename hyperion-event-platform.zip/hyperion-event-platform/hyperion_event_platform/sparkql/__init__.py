"""Python Spark SQL DataFrame schema management for sensible humans."""

from hyperion_event_platform.sparkql.fields.struct import ValidationResult
from hyperion_event_platform.sparkql.schema_builder import schema
from hyperion_event_platform.sparkql.accessors import path_col, path_seq, path_str, name, struct_field
from hyperion_event_platform.sparkql.formatters import pretty_schema
from hyperion_event_platform.sparkql.fields import (
    Byte,
    Integer,
    Long,
    Short,
    Decimal,
    Double,
    Float,
    String,
    Binary,
    Boolean,
    Date,
    Timestamp,
    Array,
    Struct,
)
from hyperion_event_platform.sparkql.schema_merger import merge_schemas
from hyperion_event_platform.sparkql import exceptions

__all__ = [
    "schema",
    "path_col",
    "path_seq",
    "path_str",
    "name",
    "struct_field",
    "pretty_schema",
    "Byte",
    "Integer",
    "Long",
    "Short",
    "Decimal",
    "Double",
    "Float",
    "String",
    "Binary",
    "Boolean",
    "Date",
    "Timestamp",
    "Array",
    "Struct",
    "ValidationResult",
    "merge_schemas",
    "exceptions",
]
