from pyspark.sql import SparkSession

from hyperion_event_platform.sparkql import Array, pretty_schema
from hyperion_event_platform.sparkql.fields.atomic import String, Float
from hyperion_event_platform.sparkql.fields.struct import Struct
from hyperion_event_platform.sparkql.schema_builder import schema


class Address(Struct):
    post_code = String()
    city = String()


class User(Struct):
    username = String(nullable=False)
    address = Address()


class Comment(Struct):
    message = String()
    author = User(nullable=False)


class Article(Struct):
    title = String(nullable=False)
    author = User(nullable=False)
    comments = Array(Comment())


print(pretty_schema(schema(Article)))
exit(0)


class City(Struct):
    name = String(nullable=False)
    latitude = Float()
    longitude = Float()


spark = SparkSession.builder.appName('job_name').getOrCreate()
df = spark.read.schema(schema(City)).csv('/home/srinivasan/Downloads/username.csv')
df.printSchema()
