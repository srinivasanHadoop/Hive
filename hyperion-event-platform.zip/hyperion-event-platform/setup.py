from setuptools import find_packages, setup
from hyperion_event_platform import __version__

setup(
    name="hyperion_event_platform",
    packages=find_packages(exclude=["tests", "tests.*"]),
    setup_requires=["wheel"],
    version=__version__,
    description="Databricks Labs CICD Templates Sample Project",
    author="srinivasan.ramalingam@howdengroup.com",
)
