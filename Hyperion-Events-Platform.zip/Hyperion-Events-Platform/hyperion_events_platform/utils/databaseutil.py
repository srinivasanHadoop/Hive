from contextlib import contextmanager

from pymssql import Connection
import pymssql


@contextmanager
def _get_connection(**kwargs) -> Connection:
    conn = pymssql.connect(**kwargs)
    try:
        yield conn
    finally:
        if conn:
            conn.close()


class DatabaseUtil:

    @classmethod
    def execute_query(cls, con_dict: dict, query: str, as_dict=True) -> list:
        with _get_connection(**con_dict) as cnxn:
            with cnxn.cursor(as_dict) as cur:
                cur.execute(query)
                return cur.fetchall()
