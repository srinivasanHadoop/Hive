import copy

from hyperion_events_platform.common import Job
from hyperion_events_platform.utils.databaseutil import DatabaseUtil
from dbjobadequacy.pipeline import JobPipline


class SourceToRawJob(Job):
    @staticmethod
    def __update_meta_info(row, meta_info):
        _path = f"{row.get('TABLE_CATALOG')}/{row.get('TABLE_SCHEMA')}_{row.get('TABLE_NAME')}"
        _trpath = f"dbfs:/mnt/playground/raw/{_path}"
        meta_info['dbtable'] = '(SELECT * FROM {}) as query' \
            .format(f"{row.get('TABLE_CATALOG')}.{row.get('TABLE_SCHEMA')}.{row.get('TABLE_NAME')}")
        meta_info['driver'] = 'com.microsoft.sqlserver.jdbc.SQLServerDriver'
        meta_info[
            'url'] = f"jdbc:sqlserver://{meta_info['host']}:{meta_info['port']};database={meta_info['database']};"
        meta_info['batchID'] = 1
        meta_info['pipelineID'] = 2
        meta_info['target_path'] = _trpath
        return meta_info

    def launch(self):
        self.logger.info("Launching SourceToRaw job")
        con_dict = self.__get_db_con_values()
        meta_query = "select * from INFORMATION_SCHEMA.TABLES where TABLE_TYPE='BASE TABLE'"
        for row in DatabaseUtil.execute_query(con_dict, meta_query)[:1]:
            meta_info = copy.deepcopy(con_dict)
            self.__update_meta_info(row, meta_info)
            meta_info['dbtable'] = '(SELECT * FROM {}) as query' \
                .format(f"{row.get('TABLE_CATALOG')}.{row.get('TABLE_SCHEMA')}.{row.get('TABLE_NAME')}")
            print(meta_info)
            plan = JobPipline('/dbfs/dbx/hyperion_events_platform/source_to_raw.json', self.spark, self.dbutils, meta_info)
            plan.execute_pipeline_operation()
        self.logger.info("SourceToRaw job finished!")

    def __get_db_con_values(self) -> dict:
        return {
            'host': '10.51.204.229',
            'port': '1433',
            'user': 'vmadmin',
            'password': 'admin@1234567',
            'database': 'RKH_UAT',
            'autocommit': True
        }


if __name__ == '__main__':
    job = SourceToRawJob()
    job.launch()
