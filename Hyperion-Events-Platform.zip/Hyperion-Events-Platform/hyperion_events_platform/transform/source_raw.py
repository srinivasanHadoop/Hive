from functools import reduce, partial

from dbjobadequacy.transform.spark.base import AbstractDataTransForm
from pyspark.sql import DataFrame
from pyspark.sql.functions import expr, lit, current_timestamp


def transform(self, f):
    return f(self)


DataFrame.transform = transform


class SourceToRawTransform(AbstractDataTransForm):

    def pre_data_validate(self, df: DataFrame) -> (bool, Exception):
        return (True, None)

    @staticmethod
    def __add_event_meta_info(df: DataFrame, meta_info: dict) -> DataFrame:
        def add_meta_info(meta_info, df):
            if not meta_info:
                return df
            return reduce(lambda mdf, colname:
                          mdf.withColumn(colname, lit(meta_info.get(colname))),
                          meta_info.keys(), df)

        return df.withColumn('EventId',
                             expr('java_method("java.util.UUID","randomUUID")')) \
            .transform(partial(add_meta_info, meta_info)). \
            withColumn('JobProcessedTimestamp', current_timestamp().cast("string"))

    def data_transform(self, df: DataFrame) -> DataFrame:
        return self.__add_event_meta_info(df,
                                          self.config.get('batch_meta_info', {}))

    def post_data_validate(self, df: DataFrame) -> (bool, Exception):
        return (True, None)
