from abc import ABC, abstractmethod
from dataclasses import dataclass


class NotifierException(Exception):

    def __init__(self, *args, **kwargs):
        self.provider = kwargs.get("provider")
        self.message = kwargs.get("message")
        self.data = kwargs.get("data")
        self.response = kwargs.get("response")
        super().__init__(self.message)

    def __repr__(self):
        return f"[NotificationError: {self.message}]"


class NotificationError(NotifierException):

    def __init__(self, *args, **kwargs):
        self.errors = kwargs.pop("errors", None)
        kwargs["message"] = f'Notification errors: {",".join(self.errors)}'
        super().__init__(*args, **kwargs)

    def __repr__(self):
        return f"[NotificationError: {self.message}]"


@dataclass(frozen=True)
class Response:
    status: str
    provider: str
    data: dict
    response: dict = None
    errors: list = None

    def __repr__(self):
        return f"<Response,provider={self.provider.capitalize()},status={self.status}," \
               f" errors={self.errors}>"

    def raise_on_errors(self):
        if self.errors:
            raise NotificationError(
                provider=self.provider,
                data=self.data,
                errors=self.errors,
                response=self.response,
            )

    @property
    def ok(self):
        return self.errors is None


@dataclass(frozen=True)
class Provider(ABC):

    @property
    @abstractmethod
    def _required(self) -> dict:
        pass

    @property
    @abstractmethod
    def schema(self) -> dict:
        pass

    @property
    @abstractmethod
    def name(self) -> str:
        pass

    @abstractmethod
    def _prepare_data(self, data: dict) -> dict:
        pass

    @abstractmethod
    def _send_notification(self, data: dict) -> Response:
        pass

    def create_response(self, data: dict = None,
                        response: Response = None,
                        errors: list = None) -> Response:
        return Response(
            status='Failure' if errors else 'Success',
            provider=self.name,
            data=data,
            response=response,
            errors=errors,
        )

    def notify(self, raise_on_errors: bool = False,
               **kwargs) -> Response:
        data = self._process_data(**kwargs)
        rsp = self._send_notification(data)
        if raise_on_errors:
            rsp.raise_on_errors()
        return rsp
