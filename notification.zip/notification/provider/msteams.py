from dbjobadequacy.services.notification.provider import Provider, Response


class MsTeamsProvider(Provider):
    name = "MSTeams"
    _required = {"required": ["teams_connection_string"]}
    schema = {
        "type": "object",
        "properties": {
            "teams_connection_string": {
                "type": "string",
                "format": "uri",
                "title": "teams_connection_string used to establish the connection to teams",
            }
        }
    }

    def _prepare_data(self, data: dict) -> dict:
        pass

    def _send_notification(self, data: dict) -> Response:
        pass
